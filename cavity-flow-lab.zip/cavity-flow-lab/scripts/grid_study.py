"""Simple grid sweep. Fixed step counts are not a steady-state criterion."""
import argparse
import csv
from pathlib import Path
from cavity_flow import CavityConfig, CavitySolver


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--grids", type=int, nargs="+", default=[32, 64, 128])
    p.add_argument("--re", type=float, default=100.0)
    p.add_argument("--steps", type=int, default=2000)
    p.add_argument("--output", type=Path, default=Path("results/grid_study.csv"))
    a = p.parse_args(); a.output.parent.mkdir(parents=True, exist_ok=True); rows = []
    for n in a.grids:
        s = CavitySolver(CavityConfig(nx=n, ny=n, reynolds=a.re))
        s.run(a.steps, log_every=max(1, a.steps//10))
        row = {"nx": n, "ny": n, "reynolds": a.re, "steps": s.iteration,
               "time": s.time, "divergence_linf": s.divergence_linf(), "kinetic_energy": s.kinetic_energy()}
        rows.append(row); print(row)
    with a.output.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"Wrote {a.output}")

if __name__ == "__main__": main()
