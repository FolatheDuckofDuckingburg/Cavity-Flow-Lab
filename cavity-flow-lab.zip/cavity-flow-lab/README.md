# Cavity Flow Lab

A small, reproducible 2D incompressible lid-driven cavity solver for learning and numerical-method development.

**Scope:** this project computes one canonical flow problem. It does not solve the general Navier–Stokes Millennium Prize problem. Small divergence and low benchmark error are useful diagnostics, not proof of correctness.

## Method and current limitations

- MAC-style staggered fields: `u (ny, nx+1)`, `v (ny+1, nx)`, cell-centred pressure `p (ny, nx)`.
- Explicit advection/diffusion predictor followed by a pressure-correction projection.
- Jacobi pressure-Poisson iteration with a reported residual.
- CSV diagnostics and velocity/streamline plots.

This is an intentionally transparent starter implementation, **not yet a validated research solver**. Pressure boundary conditions and consistency between discrete divergence, gradient, and Poisson operators must be checked. The moving-lid corners are singular. Time-step sensitivity and grid convergence are required before making accuracy claims.

## Install

Python 3.10+:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -e ".[dev]"
```

## Run

```bash
cavity-flow --re 100 --nx 64 --ny 64 --steps 3000 --output results/re100_64
pytest
python scripts/grid_study.py --grids 32 64 128 --re 100 --steps 3000
```

The grid study records diagnostics at the requested step count; it does **not** establish steady state. Compare grids at matched physical times or use a justified convergence criterion.

## Governing equations

For constant density and kinematic viscosity:

\[
\partial_t\mathbf{u}+(\mathbf{u}\cdot\nabla)\mathbf{u}=-\nabla p+\nu\nabla^2\mathbf{u},\qquad \nabla\cdot\mathbf{u}=0.
\]

With cavity length `L=1` and lid speed `U=1`, `Re=UL/nu`, so `nu=1/Re`. Pressure is scaled by density.

## Validation checklist

See [`docs/VALIDATION.md`](docs/VALIDATION.md). The classic comparison is Ghia, Ghia & Shin (1982), *Journal of Computational Physics* 48, 387–411. Add a traceable copy of the exact benchmark data and document its provenance before automating benchmark claims.
