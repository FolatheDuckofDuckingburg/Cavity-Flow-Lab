# Numerical validation checklist

This is a plan, not a statement that the solver has passed validation.

- [ ] Verify the discrete pressure-correction equation is algebraically consistent with the divergence and gradient operators.
- [ ] Check the Poisson residual against the same operator used in iteration; report whether the iteration cap was reached.
- [ ] Check discrete divergence after projection for multiple grids and time steps.
- [ ] Tighten pressure tolerance and raise iteration cap; quantify output sensitivity.
- [ ] Halve the time step and compare at matched physical time.
- [ ] Establish a steady-state criterion using velocity-field changes over a documented window.
- [ ] Compare centreline velocity profiles with traceable Ghia et al. benchmark data.
- [ ] Report vortex centres, norms, and grid-refinement trends.
- [ ] Document corner treatment, software versions, configuration, and commit SHA.
- [ ] Add regression tests only after independently verifying benchmark data and interpolation.

## Key caveat

The current pressure-correction and boundary treatment is a starter implementation requiring independent review. In particular, ensure the cell-centred Neumann Poisson operator and staggered-grid divergence/gradient pair are compatible. Do not describe the solver as validated until this work is done.
